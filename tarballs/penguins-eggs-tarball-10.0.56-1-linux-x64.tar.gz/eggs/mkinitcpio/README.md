# Arch families

After Debian/Devuan/Ubuntu I decided to bring eggs under Arch and thanx to the collaboration of stefano@manjaro.com we was able to remaster linuxmanjaro since january 2022.

Actually, we are on may 2023, Arch, RebornOS, EndeavourOS are working well with archlinux mkinitcpio.

The same for ManjaroLinux.

We have problems with blendos and crystal and sometime I don't know how to ask help and how to find.

## informations about mkinitcpio

[mkinitcpio documantation](https://wiki.archlinux.org/title/mkinitcpio)

## Repositories

* [mkinitcpio](https://gitlab.archlinux.org/archlinux/mkinitcpio)
* [mkinitcpio-archiso](https://gitlab.archlinux.org/archlinux/mkinitcpio/mkinitcpio-archiso/-/tree/master/docs)

