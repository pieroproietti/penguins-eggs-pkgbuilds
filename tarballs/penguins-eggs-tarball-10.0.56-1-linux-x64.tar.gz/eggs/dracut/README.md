# dracut on Fedora

## Install

### fedora 
```
sudo dnf -y install \
	dracut \
	dracut-live
```

### opensuse
```
sudo zypper -y install \
	dracut \
	dracut-tools
```

