# Debian 13 trixie

It take all configuration from Debian buster

Used by
- trixie

ISSUES
* added 28 luly 2023
