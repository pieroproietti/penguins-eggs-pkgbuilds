# Devuan excalibur

It take all configuration of Debian buster