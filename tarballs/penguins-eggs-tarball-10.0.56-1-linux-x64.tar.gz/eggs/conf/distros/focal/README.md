# Ubuntu 22.04 jammy

It take all configuration from Ubuntu noble from august 2024
