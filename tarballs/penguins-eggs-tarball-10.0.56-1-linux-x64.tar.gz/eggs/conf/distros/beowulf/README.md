# Devuan beowulf

It take all configuration of Debian buster