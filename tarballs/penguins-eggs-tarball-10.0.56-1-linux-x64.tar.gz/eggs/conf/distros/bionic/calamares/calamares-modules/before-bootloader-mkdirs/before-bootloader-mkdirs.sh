cp /lib/live/mount/medium/live/vmlinuz /boot/vmlinuz-$(uname -r)
