touch /boot/initrd.img-$(uname -r)
