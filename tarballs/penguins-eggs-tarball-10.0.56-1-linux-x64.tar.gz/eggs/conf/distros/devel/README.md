# Ubuntu Rhino devel

It take all configuration from Ubuntu noble from august 2024
